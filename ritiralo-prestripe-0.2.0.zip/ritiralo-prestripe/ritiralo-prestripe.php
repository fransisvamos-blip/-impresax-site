<?php
/**
 * Plugin Name: Ritiralo Pre-Stripe Bridge
 * Description: Safe pre-Stripe bridge: payment handoff/readiness, secure payment return URLs, utility noindex and read-only Aruba shipment fallbacks.
 * Version: 0.2.0
 * Author: Ritiralo
 */
if (!defined('ABSPATH')) { exit; }

define('RITIRALO_PRESTRIPE_VERSION', '0.2.0');
define('RITIRALO_PRESTRIPE_URL', plugin_dir_url(__FILE__));

final class Ritiralo_PreStripe_Bridge {
    public static function boot() {
        add_action('rest_api_init', [__CLASS__, 'rest'], 30);
        add_action('wp_enqueue_scripts', [__CLASS__, 'assets'], 30);
        add_filter('http_request_args', [__CLASS__, 'stripe_checkout_return_urls'], 20, 2);
        add_filter('wp_robots', [__CLASS__, 'robots']);
    }

    public static function rest() {
        register_rest_route('ritiralo/v1/payment', '/readiness', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'readiness'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('ritiralo/v1/prelaunch', '/shipments', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'shipments'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('ritiralo/v1/prelaunch', '/shipments/(?P<id>[0-9a-fA-F-]{36})', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'shipment'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('ritiralo/v1/prelaunch', '/shipments/(?P<id>[0-9a-fA-F-]{36})/tracking', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'tracking'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('ritiralo/v1/prelaunch', '/shipments/(?P<id>[0-9a-fA-F-]{36})/label', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'label'],
            'permission_callback' => '__return_true',
        ]);
    }

    public static function readiness() {
        $key = '';
        if (class_exists('Ritiralo_Payment_Config')) {
            $key = (string) Ritiralo_Payment_Config::stripe_secret_key();
        } else {
            $key = defined('STRIPE_SECRET_KEY') ? (string)STRIPE_SECRET_KEY : (string)getenv('STRIPE_SECRET_KEY');
        }
        $configured = $key !== '';
        $mode = !$configured ? 'unconfigured' : (str_starts_with($key,'sk_test_') ? 'test' : (str_starts_with($key,'sk_live_') ? 'live' : 'configured'));
        return new WP_REST_Response(['ok'=>true,'data'=>[
            'configured'=>$configured,
            'mode'=>$mode,
            'shipment_create_enabled'=>false,
            'browser_success_is_authoritative'=>false,
        ]],200);
    }

    private static function require_shipping_user(WP_REST_Request $r) {
        if (!class_exists('Ritiralo_Shipping_Identity')) {
            throw new RuntimeException('Shipping identity non disponibile.');
        }
        $identity = new Ritiralo_Shipping_Identity();
        return $identity->require_user_id($r);
    }

    private static function shipping_rpc($fn, array $payload) {
        if (!class_exists('Ritiralo_Shipping_Config')) {
            throw new RuntimeException('Shipping config non disponibile.');
        }
        $base = rtrim((string)Ritiralo_Shipping_Config::neon_data_api(),'/');
        $secret = (string)Ritiralo_Shipping_Config::neon_rpc_secret();
        if ($base==='' || $secret==='') { throw new RuntimeException('Neon shipping non configurato.'); }

        $jwt = self::neon_anon_jwt();
        $res = wp_remote_post($base.'/rpc/'.rawurlencode($fn),[
            'timeout'=>20,
            'redirection'=>0,
            'headers'=>[
                'Content-Type'=>'application/json',
                'Accept'=>'application/json',
                'Authorization'=>'Bearer '.$jwt,
            ],
            'body'=>wp_json_encode(['p_secret'=>$secret,'p_payload'=>$payload]),
        ]);
        if (is_wp_error($res)) { throw new RuntimeException('Persistenza shipping non disponibile.'); }
        $code=(int)wp_remote_retrieve_response_code($res);
        $data=json_decode((string)wp_remote_retrieve_body($res),true);
        if ($code<200 || $code>=300 || !is_array($data)) {
            if ($code===401 || $code===403) { throw new RuntimeException('Spedizione non accessibile.'); }
            if ($code===404) { throw new RuntimeException('Spedizione non trovata.'); }
            throw new RuntimeException('Lettura shipping non disponibile.');
        }
        return $data;
    }

    private static function neon_anon_jwt() {
        $cached=get_transient('ritiralo_prestripe_neon_anon_jwt');
        if (is_string($cached) && substr_count($cached,'.')===2) { return $cached; }
        if (!class_exists('Ritiralo_Shipping_Config')) { throw new RuntimeException('Neon Auth non disponibile.'); }
        $base=rtrim((string)Ritiralo_Shipping_Config::neon_auth_url(),'/');
        if ($base==='') { throw new RuntimeException('Neon Auth non configurato.'); }
        $origin=rtrim(home_url(),'/');
        $res=wp_remote_get($base.'/token/anonymous',[
            'timeout'=>15,
            'redirection'=>0,
            'headers'=>['Accept'=>'application/json','Origin'=>$origin,'Referer'=>$origin.'/'],
        ]);
        if (is_wp_error($res)) { throw new RuntimeException('Token Neon non disponibile.'); }
        $body=json_decode((string)wp_remote_retrieve_body($res),true);
        $candidates=[];
        $headers=wp_remote_retrieve_headers($res);
        if (is_object($headers) && method_exists($headers,'offsetGet')) {
            foreach(['set-auth-jwt','x-auth-jwt','authorization'] as $hn){
                $v=$headers->offsetGet($hn);
                if(is_string($v)&&$v!=='')$candidates[]=$v;
            }
        }
        if (is_array($body)) {
            foreach(['token','jwt','access_token','authToken','auth_token'] as $k) if(isset($body[$k])&&is_string($body[$k]))$candidates[]=$body[$k];
            foreach(['data','session'] as $p) if(isset($body[$p])&&is_array($body[$p])) {
                foreach(['token','jwt','access_token','authToken','auth_token'] as $k) if(isset($body[$p][$k])&&is_string($body[$p][$k]))$candidates[]=$body[$p][$k];
            }
        }
        foreach($candidates as $v){
            $v=trim((string)$v);
            if(stripos($v,'Bearer ')===0)$v=trim(substr($v,7));
            if(substr_count($v,'.')===2 && strlen($v)>40){set_transient('ritiralo_prestripe_neon_anon_jwt',$v,600);return $v;}
        }
        throw new RuntimeException('Token Neon non valido.');
    }

    public static function shipments(WP_REST_Request $r) {
        try{
            $uid=self::require_shipping_user($r);
            $data=self::shipping_rpc('ritiralo_list_shipments',['user_id'=>$uid]);
            return new WP_REST_Response(['ok'=>true,'data'=>$data],200);
        }catch(Throwable $e){
            return new WP_REST_Response(['ok'=>false,'error'=>['code'=>'SHIPMENT_READ_UNAVAILABLE','message'=>'Le spedizioni non sono disponibili in questo momento.']],503);
        }
    }

    public static function shipment(WP_REST_Request $r) {
        try{
            $uid=self::require_shipping_user($r);
            $data=self::shipping_rpc('ritiralo_get_shipment',['user_id'=>$uid,'shipment_id'=>(string)$r['id']]);
            return new WP_REST_Response(['ok'=>true,'data'=>$data],200);
        }catch(Throwable $e){
            return new WP_REST_Response(['ok'=>false,'error'=>['code'=>'SHIPMENT_READ_UNAVAILABLE','message'=>'Spedizione non disponibile.']],503);
        }
    }

    public static function tracking(WP_REST_Request $r) {
        try{
            $uid=self::require_shipping_user($r);
            $data=self::shipping_rpc('ritiralo_get_shipment',['user_id'=>$uid,'shipment_id'=>(string)$r['id']]);
            $ship=$data['shipment']??null;
            if(!is_array($ship) || empty($ship['tracking_number'])) {
                return new WP_REST_Response(['ok'=>false,'error'=>['code'=>'TRACKING_UNAVAILABLE','message'=>'Tracking non disponibile.']],404);
            }
            if(!class_exists('Ritiralo_Shipping_Provider_Client') || !class_exists('Ritiralo_Shipping_Connection_Registry') || !class_exists('Ritiralo_Shipping_Normalizer')) {
                throw new RuntimeException('Provider shipping non disponibile.');
            }
            $provider=new Ritiralo_Shipping_Provider_Client(new Ritiralo_Shipping_Connection_Registry());
            $raw=$provider->tracking((string)$ship['provider_connection_id'],(string)$ship['tracking_number']);
            $normalized=(new Ritiralo_Shipping_Normalizer())->tracking((array)$raw['data'],(string)$ship['provider_connection_id']);
            return new WP_REST_Response(['ok'=>true,'data'=>$normalized],200);
        }catch(Throwable $e){
            return new WP_REST_Response(['ok'=>false,'error'=>['code'=>'TRACKING_UNAVAILABLE','message'=>'Tracking temporaneamente non disponibile.']],503);
        }
    }

    public static function label(WP_REST_Request $r) {
        try{
            $uid=self::require_shipping_user($r);
            $data=self::shipping_rpc('ritiralo_get_shipment',['user_id'=>$uid,'shipment_id'=>(string)$r['id']]);
            $ship=$data['shipment']??null;
            if(!is_array($ship) || empty($ship['provider_shipment_id'])) {
                return new WP_REST_Response(['ok'=>false,'error'=>['code'=>'LABEL_UNAVAILABLE','message'=>'Etichetta non disponibile.']],404);
            }
            if(!class_exists('Ritiralo_Shipping_Provider_Client') || !class_exists('Ritiralo_Shipping_Connection_Registry')) {
                throw new RuntimeException('Provider shipping non disponibile.');
            }
            $provider=new Ritiralo_Shipping_Provider_Client(new Ritiralo_Shipping_Connection_Registry());
            $x=$provider->label((string)$ship['provider_connection_id'],(string)$ship['provider_shipment_id']);
            if(headers_sent())throw new RuntimeException('Headers already sent.');
            status_header(200);
            header('Content-Type: application/pdf');
            header('Cache-Control: private, no-store');
            header('X-Content-Type-Options: nosniff');
            echo $x['binary'];
            exit;
        }catch(Throwable $e){
            return new WP_REST_Response(['ok'=>false,'error'=>['code'=>'LABEL_UNAVAILABLE','message'=>'Etichetta temporaneamente non disponibile.']],503);
        }
    }

    public static function assets() {
        if (is_admin()) { return; }
        wp_enqueue_script('ritiralo-prestripe',RITIRALO_PRESTRIPE_URL.'assets/ritiralo-prestripe.js',[],RITIRALO_PRESTRIPE_VERSION,true);
    }

    public static function stripe_checkout_return_urls($args,$url) {
        if (stripos((string)$url,'/checkout/sessions')===false) return $args;
        if (strtoupper((string)($args['method']??'GET'))!=='POST' || empty($args['body'])) return $args;
        $params=[];
        if(is_string($args['body']))parse_str($args['body'],$params);
        elseif(is_array($args['body']))$params=$args['body'];
        if(!is_array($params))return $args;
        $pid=(string)($params['metadata']['ritiralo_payment_id']??($params['client_reference_id']??''));
        if(!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i',$pid))return $args;
        $params['success_url']=add_query_arg(['state'=>'return','payment_id'=>$pid],home_url('/pagamento/'));
        $params['cancel_url']=add_query_arg(['state'=>'cancelled','payment_id'=>$pid],home_url('/pagamento/'));
        $args['body']=is_string($args['body'])?http_build_query($params,'','&',PHP_QUERY_RFC3986):$params;
        return $args;
    }

    public static function robots($robots) {
        if(is_page(['registrati','verifica-email','accedi','password-dimenticata','reset-password','area-personale','pagamento'])){
            $robots['noindex']=true;$robots['nofollow']=true;$robots['noarchive']=true;unset($robots['max-image-preview']);
        }
        return $robots;
    }
}
Ritiralo_PreStripe_Bridge::boot();
