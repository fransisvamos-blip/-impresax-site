(()=>{
'use strict';
const paymentReadiness='/wp-json/ritiralo/v1/payment/readiness';
const paymentCreate='/wp-json/ritiralo/v1/payment/create';
const preBase='/wp-json/ritiralo/v1/prelaunch';
let readiness=null,readinessPromise=null;

function coreScript(){return document.querySelector('script[data-ritiralo-core="1"]');}
async function token(){
  const s=coreScript(),base=s&&s.dataset?s.dataset.ritiraloAuthBase:'';
  if(!base)return null;
  try{
    const r=await fetch(base.replace(/\/$/,'')+'/token',{method:'GET',credentials:'include',headers:{Accept:'application/json'},cache:'no-store'});
    if(!r.ok)return null;const j=await r.json();const t=j.token||j.access_token||j.jwt||null;return typeof t==='string'&&t.length>20?t:null;
  }catch(e){return null}
}
async function authHeaders(extra){
  const h=Object.assign({Accept:'application/json'},extra||{}),t=await token();if(t)h.Authorization='Bearer '+t;return h;
}
async function getJson(url){
  const r=await fetch(url,{method:'GET',credentials:'same-origin',cache:'no-store',headers:await authHeaders()});
  let j={};try{j=await r.json()}catch(e){}
  if(!r.ok||!j||j.ok!==true){const e=new Error((j&&j.error&&j.error.message)||'Operazione non disponibile.');e.code=j&&j.error&&j.error.code||'UNAVAILABLE';throw e}
  return j.data;
}
async function labelBlob(id){
  const r=await fetch(preBase+'/shipments/'+encodeURIComponent(id)+'/label',{method:'GET',credentials:'same-origin',cache:'no-store',headers:await authHeaders({'X-Ritiralo-Shipping':'1','Accept':'application/pdf'})});
  if(!r.ok){let j={};try{j=await r.json()}catch(e){}const e=new Error((j&&j.error&&j.error.message)||'Etichetta non disponibile.');e.code=j&&j.error&&j.error.code||'LABEL_UNAVAILABLE';throw e}
  return r.blob();
}
async function getReadiness(){
  if(readiness)return readiness;if(readinessPromise)return readinessPromise;
  readinessPromise=fetch(paymentReadiness,{credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'}}).then(r=>r.json().then(j=>({r,j}))).then(({r,j})=>{if(!r.ok||!j||j.ok!==true)throw new Error();readiness=j.data||{};return readiness}).catch(()=>({configured:false,mode:'unavailable'})).finally(()=>{readinessPromise=null});
  return readinessPromise;
}
function emit(name,params){try{window.dataLayer=window.dataLayer||[];window.dataLayer.push(Object.assign({event:name},params||{}))}catch(e){}try{if(typeof window.gtag==='function')window.gtag('event',name,params||{})}catch(e){}}
async function createPayment(quoteId){
  const h=await authHeaders({'Content-Type':'application/json','X-Ritiralo-Payment':'1'});
  const r=await fetch(paymentCreate,{method:'POST',credentials:'same-origin',cache:'no-store',headers:h,body:JSON.stringify({quote_request_id:quoteId})});
  let j={};try{j=await r.json()}catch(e){}
  if(!r.ok||!j||j.ok!==true){const e=new Error((j&&j.error&&j.error.message)||'Pagamento temporaneamente non disponibile.');e.code=j&&j.error&&j.error.code||'PAYMENT_UNAVAILABLE';throw e}
  return j.data;
}
function setButtonState(btn,ready){
  if(!btn)return;
  if(ready&&ready.configured){btn.disabled=false;btn.removeAttribute('aria-disabled');btn.textContent=ready.mode==='test'?'Paga in modalità test':'Paga in sicurezza';btn.dataset.paymentReady='1'}
  else{btn.disabled=true;btn.setAttribute('aria-disabled','true');btn.textContent='Pagamento in preparazione';btn.dataset.paymentReady='0'}
}
async function wireButton(btn){
  if(!btn||btn.dataset.prestripeBound==='1')return;btn.dataset.prestripeBound='1';
  const ready=await getReadiness();setButtonState(btn,ready);
  btn.addEventListener('click',async()=>{
    if(btn.disabled||btn.dataset.paymentReady!=='1')return;
    const quoteId=String(btn.dataset.quoteId||'');if(!/^[0-9a-f-]{36}$/i.test(quoteId))return;
    const old=btn.textContent;btn.disabled=true;btn.textContent='Apro il pagamento…';
    try{
      emit('ritiralo_checkout_start',{quote_id:quoteId.slice(0,8)});
      const p=await createPayment(quoteId);if(p&&p.payment_id){try{sessionStorage.setItem('ritiralo_last_payment_id',String(p.payment_id))}catch(e){}}
      if(!p||!p.checkout_url)throw new Error('Checkout URL non disponibile.');location.assign(p.checkout_url);
    }catch(e){
      if(e.code==='STRIPE_KEYS_REQUIRED'){readiness={configured:false,mode:'unconfigured'};setButtonState(btn,readiness)}
      else{btn.disabled=false;btn.textContent=old}
      emit('ritiralo_checkout_error',{code:e.code||'PAYMENT_UNAVAILABLE'});
      document.dispatchEvent(new CustomEvent('ritiralo:payment:error',{detail:{code:e.code||'PAYMENT_UNAVAILABLE',message:e.message||'Pagamento non disponibile.'}}));
    }
  });
}
function scan(){document.querySelectorAll('[data-payment-start]').forEach(wireButton)}
document.addEventListener('DOMContentLoaded',scan);
document.addEventListener('ritiralo:precheckout:ready',()=>{readiness=null;scan()});
new MutationObserver(scan).observe(document.documentElement,{childList:true,subtree:true});

Object.defineProperty(window,'RitiraloPreStripe',{value:Object.freeze({
  version:'0.2.0',
  listShipments:()=>getJson(preBase+'/shipments'),
  getShipment:(id)=>getJson(preBase+'/shipments/'+encodeURIComponent(id)),
  tracking:(id)=>getJson(preBase+'/shipments/'+encodeURIComponent(id)+'/tracking'),
  labelBlob
}),configurable:false,writable:false});
})();
